const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),WebSocket=require('ws');
const DATA=path.join(__dirname,'data.json'); function load(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch{return {users:{},rooms:{}}}} function save(x){fs.writeFileSync(DATA,JSON.stringify(x,null,2))}
const db=load(),clients=new Map();
const scenarios={classic:{name:'کلاسیک',min:5,max:16,roles:['شهروند ساده','شهروند ساده','شهروند ساده','دکتر','کارآگاه','مافیا ساده','مافیا ساده','پدرخوانده']},nostradamus:{name:'پدرخوانده — نوسترآداموس',min:11,max:16,roles:['پدرخوانده','ماتادور','سال گودمن','دکتر واتسون','لئون حرفه‌ای','همشهری کین','کنتانتین','شهروند ساده','نوسترآداموس']},elclassico:{name:'ال‌کلاسیکو — روایت تسلا',min:11,max:16,roles:['پابلو اسکوبار','خوآن ولاسکوئز','گریسلدا بلانکو','چرچیل','دکتر بریجیت','مورنو','ژنرال بناپارت','افسر مارتینز','چاپلین','شهروند ساده']}};
function H(p,s){return crypto.scryptSync(p,s,64).toString('hex')} function send(w,x){if(w.readyState===1)w.send(JSON.stringify(x))}
function bc(r,x){r.players.forEach(p=>{let w=clients.get(p.id);if(w)send(w,x)})}
function code(){return 'MF-'+crypto.randomBytes(2).toString('hex').toUpperCase()}
function assign(ps,s){let a=[...s.roles];while(a.length<ps.length)a.push('شهروند ساده');while(a.length>ps.length){let i=a.indexOf('شهروند ساده');if(i<0)break;a.splice(i,1)}for(let i=a.length-1;i;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return ps.map((p,i)=>({...p,role:a[i]}))}
const html=fs.readFileSync(path.join(__dirname,'index.html'));
const httpServer=http.createServer((q,r)=>{
 if(q.url==='/health'){r.writeHead(200,{'Content-Type':'application/json'});return r.end(JSON.stringify({ok:true,service:'MAFIA FACT V25',time:new Date().toISOString()}))}
 r.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});r.end(html)
});
const wss=new WebSocket.Server({server:httpServer});
wss.on('connection',w=>w.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
if(m.t==='register'){if(db.users[m.u])return send(w,{t:'err',m:'نام کاربری قبلاً ثبت شده است'});let s=crypto.randomBytes(16).toString('hex');db.users[m.u]={hash:H(m.p,s),salt:s,name:m.name||m.u,xp:0,games:0,wins:0};save(db);send(w,{t:'ok',m:'ثبت‌نام موفق بود'})}
if(m.t==='login'){let u=db.users[m.u];if(!u||H(m.p,u.salt)!==u.hash)return send(w,{t:'err',m:'نام کاربری یا رمز نادرست است'});w.user={id:m.u,name:u.name};clients.set(m.u,w);send(w,{t:'login',name:u.name,xp:u.xp})}
if(m.t==='create'){let s=scenarios[m.sc];if(!w.user||!s)return;let c=code();db.rooms[c]={code:c,scenario:m.sc,host:w.user.id,players:[{id:w.user.id,name:w.user.name,ready:false}],started:false};save(db);send(w,{t:'room',room:db.rooms[c]})}
if(m.t==='join'){let r=db.rooms[m.c],s=r&&scenarios[r.scenario];if(!r)return send(w,{t:'err',m:'اتاق پیدا نشد'});if(r.started)return send(w,{t:'err',m:'بازی شروع شده است'});if(r.players.length>=s.max)return send(w,{t:'err',m:'اتاق پر است'});if(!r.players.some(p=>p.id===w.user.id))r.players.push({id:w.user.id,name:w.user.name,ready:false});save(db);bc(r,{t:'room',room:r})}
if(m.t==='ready'){let r=db.rooms[m.c];if(!r)return;let p=r.players.find(x=>x.id===w.user.id);if(p)p.ready=!p.ready;save(db);bc(r,{t:'room',room:r})}
if(m.t==='start'){let r=db.rooms[m.c],s=r&&scenarios[r.scenario];if(!r||r.host!==w.user.id||r.players.length<s.min)return; r.started=true;r.players=assign(r.players,s);save(db);r.players.forEach(p=>{let c=clients.get(p.id);if(c)send(c,{t:'game',scenario:s.name,players:r.players.map(x=>({name:x.name,role:x.id===p.id?x.role:'مخفی'}))})})}
}));
const PORT=Number(process.env.PORT||8080);
const HOST=process.env.HOST||'0.0.0.0';
httpServer.listen(PORT,HOST,()=>console.log(`MAFIA FACT V25: http://${HOST}:${PORT}`));