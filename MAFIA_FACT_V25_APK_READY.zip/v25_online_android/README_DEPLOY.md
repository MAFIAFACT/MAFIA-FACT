# MAFIA FACT V25 — Online Android

## Server
This folder is deploy-ready for a Node/WebSocket host. It uses `PORT` from the hosting provider and binds to `0.0.0.0`.

### Local
```bash
npm install
npm start
```
Then open `http://localhost:8080` and use `ws://localhost:8080` in the app.

### Public internet
Deploy this folder to a Node/Docker host. The public WebSocket URL must be HTTPS/WSS-capable, e.g. `wss://YOUR-DOMAIN`.
The Android app's server field accepts `https://` and automatically converts it to `wss://`.

### Important
This prototype stores accounts/rooms in `data.json`. On hosts with ephemeral storage, data can reset after a restart/deploy. For production, move accounts/rooms to a persistent database.

## Android
Open the Android project in Android Studio and build the APK. Enter the public `wss://...` address in the connection box.
