MAFIA FACT V25 - Android + Online Server

This package contains both the Android client and a deploy-ready Node.js/WebSocket server.

SERVER:
  npm install
  npm start
  local test: ws://localhost:8080

PUBLIC:
  Deploy this folder to a Node/Docker host. Use the public WSS address in the Android app,
  for example wss://YOUR-DOMAIN.

ANDROID:
  Open the project in Android Studio, build APK, then enter the public WSS address in the
  connection box.

IMPORTANT:
  The server currently stores prototype data in data.json. For production use a persistent
  database and HTTPS/WSS.
