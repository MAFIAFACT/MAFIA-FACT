const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),WebSocket=require('ws');
const DATA=path.join(__dirname,'data.json');
function load(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch{return {users:{},rooms:{},assets:[],transfers:[]}}}
function save(x){fs.writeFileSync(DATA,JSON.stringify(x,null,2))}
const db=load(); db.users??={}; db.rooms??={}; db.assets??=[]; db.transfers??=[]; db.clans??=[]; const clients=new Map();
const scenarios={classic:{name:'کلاسیک',min:5,max:16,roles:['شهروند ساده','شهروند ساده','شهروند ساده','دکتر','کارآگاه','مافیا ساده','مافیا ساده','پدرخوانده']},nostradamus:{name:'پدرخوانده — نوسترآداموس',min:11,max:16,roles:['پدرخوانده','ماتادور','سال گودمن','دکتر واتسون','لئون حرفه‌ای','همشهری کین','کنتانتین','شهروند ساده','نوسترآداموس']},elclassico:{name:'ال‌کلاسیکو — روایت تسلا',min:11,max:16,roles:['پابلو اسکوبار','خوآن ولاسکوئز','گریسلدا بلانکو','چرچیل','دکتر بریجیت','مورنو','ژنرال بناپارت','افسر مارتینز','چاپلین','شهروند ساده']}};
function H(p,s){return crypto.scryptSync(p,s,64).toString('hex')}
function send(w,x){if(w&&w.readyState===1)w.send(JSON.stringify(x))}
function userPublic(u){return {username:u.username,name:u.name,coins:u.coins||0,referralCode:u.referralCode,vip:!!u.vip}}
function notifyUser(id,x){send(clients.get(id),x)}
function code(){return 'MF-'+crypto.randomBytes(2).toString('hex').toUpperCase()}
function referral(){let c;do{c='RF-'+crypto.randomBytes(3).toString('hex').toUpperCase()}while(Object.values(db.users).some(u=>u.referralCode===c));return c}
function assign(ps,s){let a=[...s.roles];while(a.length<ps.length)a.push('شهروند ساده');while(a.length>ps.length){let i=a.indexOf('شهروند ساده');if(i<0)break;a.splice(i,1)}for(let i=a.length-1;i;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return ps.map((p,i)=>({...p,role:a[i]}))}
const html=fs.readFileSync(path.join(__dirname,'index.html'));
const httpServer=http.createServer((q,r)=>{if(q.url==='/'){r.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return r.end(html)}r.writeHead(404);r.end()});
const wss=new WebSocket.Server({server:httpServer});
wss.on('connection',w=>w.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
if(m.t==='register'){
 if(db.users[m.u])return send(w,{t:'err',m:'نام کاربری قبلاً ثبت شده است'});
 let s=crypto.randomBytes(16).toString('hex');
 db.users[m.u]={username:m.u,hash:H(m.p,s),salt:s,name:m.name||m.u,xp:0,games:0,wins:0,coins:0,referralCode:referral(),vip:false,transfers:[]};
 save(db); send(w,{t:'ok',m:'ثبت‌نام موفق بود؛ کد رفرال شما: '+db.users[m.u].referralCode});
}
if(m.t==='login'){
 let u=db.users[m.u]; if(!u||H(m.p,u.salt)!==u.hash)return send(w,{t:'err',m:'نام کاربری یا رمز نادرست است'});
 u.coins??=0;u.transfers??=[];u.referralCode??=referral();u.vip??=false;save(db);w.user={id:m.u,name:u.name};clients.set(m.u,w);send(w,{t:'login',user:userPublic(u),transfers:u.transfers,assets:db.assets.filter(a=>a.status!=='rejected'),clans:db.clans});
}
if(!w.user)return;
if(m.t==='transfer'){
 let from=db.users[w.user.id],to=Object.values(db.users).find(u=>u.referralCode===String(m.referralCode||'').trim());let amount=Number(m.amount);
 if(!Number.isInteger(amount)||amount<=0)return send(w,{t:'err',m:'تعداد سکه باید یک عدد صحیح مثبت باشد'});
 if(!to)return send(w,{t:'err',m:'کد رفرال پیدا نشد'});
 if(to.username===from.username)return send(w,{t:'err',m:'انتقال به خودتان مجاز نیست'});
 if((from.coins||0)<amount)return send(w,{t:'err',m:'موجودی سکه کافی نیست'});
 from.coins-=amount;to.coins=(to.coins||0)+amount;
 const tr={id:crypto.randomUUID(),from:from.username,to:to.username,toName:to.name,amount,date:new Date().toISOString()};from.transfers.unshift(tr);db.transfers.push(tr);save(db);
 send(w,{t:'transfer_ok',user:userPublic(from),transfers:from.transfers});notifyUser(to.username,{t:'coin_received',amount,from:from.name,balance:to.coins});
}
if(m.t==='rename'){
 let u=db.users[w.user.id], newName=String(m.name||'').trim();
 if(!newName||newName.length>40)return send(w,{t:'err',m:'نام جدید را وارد کنید'});
 if((u.coins||0)<80)return send(w,{t:'err',m:'برای تغییر نام ۸۰ سکه لازم است'});
 if(newName===u.name)return send(w,{t:'err',m:'نام جدید با نام فعلی یکسان است'});
 u.coins-=80; u.name=newName;
 Object.values(db.rooms).forEach(r=>r.players.forEach(p=>{if(p.id===u.username)p.name=newName;}));
 db.clans.forEach(c=>{if(c.leader===u.username)c.leaderName=newName;});
 save(db);
 w.user.name=newName;
 send(w,{t:'rename_ok',user:userPublic(u),m:'نام با موفقیت تغییر کرد و ۸۰ سکه کسر شد'});
}
if(m.t==='assets')send(w,{t:'assets',assets:db.assets.filter(a=>a.status!=='rejected')});
if(m.t==='clans')send(w,{t:'clans',clans:db.clans});
if(m.t==='add_clan'){
 let u=db.users[w.user.id]; if(!u.vip)return send(w,{t:'err',m:'فقط اشخاص VIP می‌توانند کلن بسازند'});
 let name=String(m.name||'').trim(); if(!name||name.length>50)return send(w,{t:'err',m:'نام کلن را وارد کنید'});
 if(db.clans.some(c=>c.name===name))return send(w,{t:'err',m:'این نام کلن قبلاً ثبت شده است'});
 const color=String(m.color||'#d4af37').trim(); if(!/^#[0-9a-fA-F]{6}$/.test(color))return send(w,{t:'err',m:'رنگ کلن نامعتبر است'}); const c={id:crypto.randomUUID(),name,description:String(m.description||''),color,leader:u.username,leaderName:u.name,members:[u.username],maxMembers:1000,date:new Date().toISOString()}; db.clans.push(c);save(db);send(w,{t:'clan_added',clan:c});
}

if(m.t==='add_asset'){
 let u=db.users[w.user.id]; if(!u.vip)return send(w,{t:'err',m:'فقط اشخاص VIP می‌توانند محتوا اضافه کنند'});
 const allowed=['scenario','avatar','frame','gravestone']; if(!allowed.includes(m.category))return send(w,{t:'err',m:'دسته محتوا نامعتبر است'});
 if(!m.name||String(m.name).length>80)return send(w,{t:'err',m:'نام محتوا را وارد کنید'});
 const a={id:crypto.randomUUID(),category:m.category,name:String(m.name),description:String(m.description||''),image:String(m.image||''),price:Number.isFinite(Number(m.price))?Number(m.price):0,roles:String(m.roles||''),creator:w.user.id,creatorName:u.name,date:new Date().toISOString(),status:'approved'};
 db.assets.push(a);save(db);send(w,{t:'asset_added',asset:a});
}
if(m.t==='create'){
 let s=scenarios[m.sc];if(!s)return;
 let prize=Math.max(0,Math.floor(Number(m.prize)||0));
 let c=code();
 db.rooms[c]={code:c,scenario:m.sc,host:w.user.id,players:[{id:w.user.id,name:w.user.name,ready:false}],started:false,prize};
 save(db);send(w,{t:'room',room:db.rooms[c]})
}
if(m.t==='join'){let r=db.rooms[m.c],s=r&&scenarios[r.scenario];if(!r)return send(w,{t:'err',m:'اتاق پیدا نشد'});if(r.started)return send(w,{t:'err',m:'بازی شروع شده است'});if(r.players.length>=s.max)return send(w,{t:'err',m:'اتاق پر است'});if(!r.players.some(p=>p.id===w.user.id))r.players.push({id:w.user.id,name:w.user.name,ready:false});save(db);r.players.forEach(p=>notifyUser(p.id,{t:'room',room:r}))}
if(m.t==='ready'){let r=db.rooms[m.c];if(!r)return;let p=r.players.find(x=>x.id===w.user.id);if(p)p.ready=!p.ready;save(db);r.players.forEach(x=>notifyUser(x.id,{t:'room',room:r}))}
if(m.t==='start'){let r=db.rooms[m.c],s=r&&scenarios[r.scenario];if(!r||r.host!==w.user.id||r.players.length<s.min)return;r.started=true;r.players=assign(r.players,s);save(db);r.players.forEach(p=>notifyUser(p.id,{t:'game',scenario:s.name,players:r.players.map(x=>({name:x.name,role:x.id===p.id?x.role:'مخفی'}))}))}
}));
httpServer.listen(process.env.PORT||8080,()=>console.log('MAFIA FACT server running'));
