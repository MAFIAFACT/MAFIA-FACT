MAFIA FACT V25.1
Features:
- Secure-ish prototype account passwords using scrypt
- Online WebSocket rooms and scenario role assignment
- Coin balance and coin transfer by player referral code
- Transfer history with timestamp
- VIP-only content creation: scenarios, avatars, frames, gravestones
- JSON persistence in data.json

Run:
npm install
node server.js
Open http://localhost:8080

Production needs HTTPS/WSS, secure sessions, database, rate limiting, moderation, upload storage, and real payment integration.


V25.3: به ساخت کلن، انتخاب رنگ نام کلن اضافه شد. رنگ با کد HEX ذخیره و در فهرست کلن نمایش داده می‌شود. فقط VIP می‌تواند کلن بسازد.


V25.5 changes:
- Each deck can optionally have a coin prize, displayed in the deck lobby.
- Changing profile name costs 80 coins; server deducts the coins and persists the new name.
